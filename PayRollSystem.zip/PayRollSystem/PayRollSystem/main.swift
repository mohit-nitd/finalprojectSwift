import Foundation
// created array of employee class
var employeeArray: [Employee] = [Employee]()
var option: Int
// answer variable is used for confirming employee has vehicle or not
var answer: Character
// vehicle type "Car" or "Motorcycle"
var vehicletype: String
var totalSalary: Double = 0
var salarySortedEmployees: Array = [Employee]()
var ageSortedEmployees: Array = [Employee]()
// idCardNumber is used for printing particular employee data
var idCardNumber: Int = 0
// variable j is used in  printing all employees data
var j: Int = 0
repeat {

    //  Press 1 to add and CommsionBasedEmployee
    print("Press 1 to add and CommsionBasedEmployee")

    //  Press 2 to add and FixedBasedPartTimeEmployee
    print("Press 2 to add and FixedBasedPartTimeEmployee")

    //  Press 3 to add and FullTime Employee
    print("Press 3 to add and FullTime Employee")

    //  Press 4 to add and Intern
    print("Press 4 to add and Intern")

    //  Press 5 to calculate all Total Salary
    print("Press 5 to calculate all Total Salary")

    //  Press 6 to Print particular Employee's data
    print("Press 6 to Print particular Employee's data")

    //  Press 7 print data of all employees
    print("Press 7 print data of all employees")

    //  Press 8 for sorting employee on the basis of employee ID with help of closures
    print("Press 8 for sorting employee on the basis of employee ID with help of closures")

    //  Press 9 for sorting employee on the basis of employee AGE with help of closures
    print("press 9 for sorting employee on the basis of employee AGE with help of closures")

    //  Press 10 to EXIT from program
    print("Press 10 to Exit From program")
    
    print("*********************************************")
    
    print("SELECT FROM THE FOLLOWING OPTIONS")
    
    print("=")
    // option variable is used for selcting user choice
    option = Int(readLine()!)!
    switch (option) {
    case  1:

        //      Commision Based Part Time employee object creation
        let  commissionBasedEmployee1 = CommisionBasedPartTime()
        print("Please enter the employee's name");
        commissionBasedEmployee1.employeeName = String(readLine()!)
        print("Please enter the employee's age");
        commissionBasedEmployee1.age = Int(readLine()!)!
        print("Please enter the employee's Id Card Number")
        commissionBasedEmployee1.employeeId = Int(readLine()!)!
        print("Please enter the number of hours worked by Employee")
        commissionBasedEmployee1.numberOfHoursWorked = Int(readLine()!)!
        print("Please enter the rate of commision for the Employee")
        commissionBasedEmployee1.rate = Int(readLine()!)!
        print("Please enter the  Commision Percentage of the Employee")
        commissionBasedEmployee1.commisionPercentage = Double(readLine()!)!
        print("Does Employee has any vehicle? Press Y for Yes N for NO")
        answer = Character(readLine()!)
        if (answer == "y" ) {
            print("What type of vehicle does the employee has Car or Motorcycle?");
            vehicletype = String(readLine()!)
            if (vehicletype == "car") {
           
            //      car object created
                
                let car1 =  Car()
                print("Enter Make of car")
                car1.make = String(readLine()!)
                print("Enter Make of Plate of car")
                car1.plate = String(readLine()!)
                print("Enter Number of seats")
                car1.numberOfSeats = Int(readLine()!)!
                commissionBasedEmployee1.vehicle = car1
                car1.printMyData();
            } else if (vehicletype == "motorcycle") {
  
                //      motorcycle object created
                let motorcycle1 =  Motorcycle()
                print("Please Enter the motocycle weight")
                motorcycle1.getKerbWeight = Int(readLine()!)!
                print("Please Enter the motocycle Make")
                motorcycle1.make = String(readLine()!)
                print("Please Enter the motocycle Plate")
                motorcycle1.plate = String(readLine()!)
                commissionBasedEmployee1.vehicle = motorcycle1
                motorcycle1.printMyData();
            }

            //         total salary calculation
            totalSalary += commissionBasedEmployee1.calcEarnings()
            commissionBasedEmployee1.printMyData()
            employeeArray.append(commissionBasedEmployee1)
            break
        }
        totalSalary += commissionBasedEmployee1.calcEarnings()
        commissionBasedEmployee1.printMyData();
        employeeArray.append(commissionBasedEmployee1)
        break;
    case 2:
 
        //      Fixed Based Part Time employee object created
        let fixedBasePartTime1 =  FixedBasePartTime()
        print("Please enter the employee's name")
        fixedBasePartTime1.employeeName = String(readLine()!)
        print("Please enter the employee's age")
        fixedBasePartTime1.age = Int(readLine()!)!
        print("Please enter the employee's Id Card Number")
        fixedBasePartTime1.employeeId = Int(readLine()!)!
        print("Please enter the number of hours worked by Employee")
        fixedBasePartTime1.numberOfHoursWorked = Int(readLine()!)!
        print("Please enter the rate of commision for the Employee")
        fixedBasePartTime1.rate = Int(readLine()!)!
        print("Please enter the  Fixed salary of the Employee")
        fixedBasePartTime1.fixedAmount = Int(readLine()!)!
        print("Does Employee has any vehicle? Press Y for Yes N for NO")
        answer = Character(readLine()!)
        if (answer == "y" ) {
            print("What type of vehicle does the employee has Car or Motorcycle?");
            vehicletype = String(readLine()!)
            if (vehicletype == "car") {
                let car1 =  Car()
                print("Enter Make of car")
                car1.make = String(readLine()!)
                print("Enter Make of Plate of car")
                car1.plate = String(readLine()!)
                print("Enter Number of seats")
                car1.numberOfSeats = Int(readLine()!)!
                fixedBasePartTime1.vehicle = car1
                car1.printMyData();
            } else if (vehicletype == "motorcycle") {
                let motorcycle1 =  Motorcycle()
                print("Please Enter the motocycle weight")
                motorcycle1.getKerbWeight = Int(readLine()!)!
                print("Please Enter the motocycle Make")
                motorcycle1.make = String(readLine()!)
                print("Please Enter the motocycle Plate")
                motorcycle1.plate = String(readLine()!)
                fixedBasePartTime1.vehicle = motorcycle1
                motorcycle1.printMyData();
            }
            totalSalary += Double(fixedBasePartTime1.calcEarning())
            fixedBasePartTime1.printMyData()
            employeeArray.append(fixedBasePartTime1)
            break
        }
        totalSalary += Double(fixedBasePartTime1.calcEarning())
       fixedBasePartTime1.printMyData();
        employeeArray.append(fixedBasePartTime1)
        break;
    case 3:
    
        // Full Time employee object created
        let fullTime1 =  FullTimeEmployee()
        print("Please enter the employee's name");
        fullTime1.employeeName = String(readLine()!)
        print("Please enter the employee's age");
        fullTime1.age = Int(readLine()!)!
        print("Please enter the employee's Id Card Number");
        fullTime1.employeeId = Int(readLine()!)!
        print("Please enter the  Employee Bonus");
        fullTime1.bonus = Double(readLine()!)!
        print("Please enter the  Employee salary");
        fullTime1.salary = Double(readLine()!)!
        print("Does Employee has any vehicle? Press Y for Yes N for NO")
        answer = Character(readLine()!)
        if (answer == "y" ) {
            print("What type of vehicle does the employee has Car or Motorcycle?");
            vehicletype = String(readLine()!)
            if (vehicletype == "car") {
                let car1 =  Car()
                print("Enter Make of car")
                car1.make = String(readLine()!)
                print("Enter Make of Plate of car")
                car1.plate = String(readLine()!)
                print("Enter Number of seats")
                car1.numberOfSeats = Int(readLine()!)!
                fullTime1.vehicle = car1
                car1.printMyData();
            } else if (vehicletype == "motorcycle") {
                let motorcycle1 =  Motorcycle()
                print("Please Enter the motocycle weight")
                motorcycle1.getKerbWeight = Int(readLine()!)!
                print("Please Enter the motocycle Make")
                motorcycle1.make = String(readLine()!)
                print("Please Enter the motocycle Plate")
                motorcycle1.plate = String(readLine()!)
                fullTime1.vehicle = motorcycle1
                motorcycle1.printMyData();
            }
            totalSalary += Double(fullTime1.calcEarning())
            fullTime1.printMyData()
            employeeArray.append(fullTime1)
            break
        }
        totalSalary += Double(fullTime1.calcEarning())
        fullTime1.printMyData()
        employeeArray.append(fullTime1)
        break;
    case 4:
   
        // Intern Object Created
        let intern1 =  Intern()
        print("Please enter the employee's name");
        intern1.employeeName = String(readLine()!)
        print("Please enter the employee's age");
        intern1.age = Int(readLine()!)!
        print("Please enter the employee's Id Card Number");
        intern1.employeeId = Int(readLine()!)!
        print("Please enter the School name of intern");
        intern1.internSchoolName = String(readLine()!)
        print("Please enter stipend of Intern");
        intern1.stipend = Int(readLine()!)!
        print("Does Employee has any vehicle? Press Y for Yes N for NO");
        answer = Character(readLine()!)
        if (answer == "y" ) {
            print("What type of vehicle does the employee has Car or Motorcycle?");
            vehicletype = String(readLine()!)
            if (vehicletype == "car") {
                let car1 =  Car()
                print("Enter Make of car")
                car1.make = String(readLine()!)
                print("Enter Make of Plate of car")
                car1.plate = String(readLine()!)
                print("Enter Number of seats")
                car1.numberOfSeats = Int(readLine()!)!
                intern1.vehicle = car1
                car1.printMyData();
            } else if (vehicletype == "motorcycle") {
                let motorcycle1 =  Motorcycle()
                print("Please Enter the motocycle weight")
                motorcycle1.getKerbWeight = Int(readLine()!)!
                print("Please Enter the motocycle Make")
                motorcycle1.make = String(readLine()!)
                print("Please Enter the motocycle Plate")
                motorcycle1.plate = String(readLine()!)
                intern1.vehicle = motorcycle1
                motorcycle1.printMyData();
            }
            totalSalary += Double(intern1.calcEarning())
            intern1.printMyData()
            employeeArray.append(intern1)
            break
        }
        totalSalary += Double(intern1.calcEarning())
        intern1.printMyData()
        employeeArray.append(intern1)
        break
    
    case 5:
        // total salary of all employees
        print("Total Payout to employees is : \(totalSalary)")
    
    case 6:
        //  print data of any particular employee
        print("Please Enter the employee id");
        idCardNumber = Int(readLine()!)!
        for j in 0...employeeArray.count {
            if (employeeArray[j].employeeId == idCardNumber) {
                employeeArray[j].printMyData()
            }
        }
        break
        
    case 7:
        // to print data of all employee
        for j in 0...employeeArray.count {
            employeeArray[j].printMyData()
            }
        break
        
    
    case 8:
        // sorted employee on the basis of employee id with help of closures
         salarySortedEmployees = employeeArray.sorted {$0.employeeId! <= $1.employeeId!}
         for j in 0...salarySortedEmployees.count {
            salarySortedEmployees[j].printMyData()
         }
        break
    case 9:
        // sorted employee on the basis of employee Age  with help of closures
        ageSortedEmployees = employeeArray.sorted {$0.age! <= $1.age!}
        for j in 0...ageSortedEmployees.count {
            ageSortedEmployees[j].printMyData()
        }
        break
        
    case 10:
        // for exit from program
        exit(0);
        break
        

   
    default:
    print("Please Enter the correct option")
        break
    }
    
}while  (option != 10)

